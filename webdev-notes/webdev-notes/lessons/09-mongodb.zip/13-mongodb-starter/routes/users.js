var express = require('express');
var router = express.Router();
const { getCollection } = require('../models/db');
const crypto = require("crypto");

router.post("/signup/submit", async (req, res) => {
  try {
    //Step 1: Get a connection to the "users" collection
    let conn = getCollection("users");
  
    //Step 2: Get the user details from the request body

    //Step 3: Check if a user with the same email already exists

    //Step 4: If user exists, redirect to /signup
    
    //Step 5: If user does not exist, create a new user in the database

    await conn.insertOne(newUser);
    res.redirect("/signin");
  } 
  catch(e) {
    console.error(e);
    res.redirect("/signup");
  }
});

router.post("/signin/submit", async (req, res) => {
  try {
    //Step 1: Get a connection to the "users" collection
    let conn = getCollection("users");

    //Step 2: Get the email and password from the request body

    //Step 3: Find the user in the database by email
    let dbuser = await conn.findOne({email: email});
    //Step 4: If user not found, redirect to /signin

    //Step 5: If user found, hash the provided password with the stored salt

    //Step 6: Compare the hashed password with the stored password

    //Step 7: If passwords match, render index page with user's name

    //Step 8: If passwords don't match, redirect to /signin
    
  } catch(e) {
    console.error(e);
  }
});

module.exports = router;
