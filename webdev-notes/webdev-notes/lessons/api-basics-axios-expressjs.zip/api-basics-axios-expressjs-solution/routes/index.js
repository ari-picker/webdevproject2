var express = require('express');
var axios = require("axios")
var router = express.Router();

/* GET Random Paragraph page */
router.get('/random-para', async (req, res) => {
    const baseURL = "http://metaphorpsum.com/"
    const endpoint = "sentences/5"
    try {
        const response = await axios.get(baseURL + endpoint);
        res.json(response.data);
    } catch (error) {
        res.status(500).send("Error fetching random paragraph");
    }
});

/* GET weather page. */
router.get('/weather', async function(req, res) {
    const baseURL = "https://api.openweathermap.org"
    const endpoint = "/data/2.5/weather"
    const myParams = {
        q: "New York",
        units: "imperial",
        lang: "en",
        appid: process.env.APIKEY
    }
    try {
        const response = await axios.get(baseURL + endpoint, { 
                params: myParams 
            }
    );
        res.json(response.data);
    } catch (error) {
        res.status(500).send("Error fetching weather data");
    }
});

module.exports = router;
