var express = require('express');
var axios = require("axios")
var router = express.Router();

/* GET Random Paragraph page */
router.get('/random-para', async (req, res) => {
    //TODO
    //work with this api: 
    //http://metaphorpsum.com/sentences/{number_of_sentences}
    //to server jokes to the user.
})

/* GET weather page. */
router.get('/weather', async function(req, res) {
    //TODO
    //work with this api: 
    //https://api.openweathermap.org/data/2.5/weather
    //to server weather info to the user.
    //You need to sign up to get an API key.
});

module.exports = router;
