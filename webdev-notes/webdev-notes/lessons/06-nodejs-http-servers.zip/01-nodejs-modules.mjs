import crypto from 'crypto';

// // Asynchronously generate a random string
crypto.randomBytes(11, (err, buf) => { //callback
  if (err) throw err;
  console.log(`Random 1: ${buf.toString('hex')}`);
});


crypto.randomBytes(11, (err, buf) => { //callback
  if (err) throw err;
  console.log(`Random 2: ${buf.toString('hex')}`);
});




// Asynchronously? generate a UUID (Universally Unique Identifier)
console.log(crypto.randomUUID());

//Store a password securely
const password = 'Password123';
const salt = 'uniqueSaltValue'; //Unique for every user
const keyLength = 11; // Length of the derived password (should be longer)
crypto.scrypt(password, salt, keyLength, (err, derivedKey) => {
  if (err) throw err;
  console.log('Derived key (hex):', derivedKey.toString('hex'));
});


// //--------------------------FS------------------------------------
// import fs from "fs";

// //Create output.txt file and write Hello World!! 
// const data = "Hello world!!";
// fs.writeFile("output.txt", data, "utf8", (err) => {
//     if(err) throw err;    
//     console.log("File written.");
// });

// //Read input.txt file and print the data
// for(let i = 10; i < 15; i++){
//   let outputFileName = `output${i}.txt`
  
//   fs.writeFile(outputFileName, outputFileName, "utf8", (err) => {
//     if(err) throw err;    
//     console.log(outputFileName);
//   });
// }

// //Create a folder and explore the conetent of it
// fs.mkdir("./directory", (err) => {
//     if(err) console.log("Failed to create folder.");
//     else {
//         for(let i = 10; i <= 15; i++){
//             fs.writeFileSync(`./directory/${i}.txt`, `File ${i}`, (err) => {
//                 if(err) console.log(`Error writing file ${i}`);
//             })
//         } 
//         displayDir();
//     }
// })

// function displayDir(){
//     fs.readdir("./directory", (err, files) => {
//         if(err) throw err;
//         for(let file of files) {
//             console.log(file);
//         }
//     })
// }


// // ------------------------DNS-----------------------------
// import dns from "dns";

// const domain = "google.com";
// dns.resolve(domain, (err, address) => {
//     if(err) throw err;
//     else console.log(`IP of ${domain}: ${address}`);
// });

// const domains = ["codepath.org", "amazon.com", 
//                  "ebay.com", "cuny.edu"];

// for(let domain of domains) {
//     dns.resolve(domain, (err, address) => {
//         if(err) console.log(`Error on ${domain}`);
//         else console.log(`IP of ${domain}: ${address}`);
//     });
// }


// // -----------------------URL------------------------------

// const url = require("url"); //Not needed as URL is global variable
// let urlObj = new URL("http://nowhere.com/?fname=john&lname=doe")
// console.log(urlObj);

// let params = new URLSearchParams("q=%22How%20to%20learn%20js?%22");
// console.log(params.get("q"));
