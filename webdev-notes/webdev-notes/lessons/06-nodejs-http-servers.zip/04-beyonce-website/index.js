
const http = require("http");
const fs = require("fs");
const port = 3000;

const server = http.createServer();

server.on("request", (req, res) => {
    let url = req.url;
    
    console.log(url)
    if(url === "/"){
        res.writeHead(200, {"Content-type": "text/html"});
        fs.createReadStream("./index.html").pipe(res);
    } 
    else if(url === "/favicon.ico"){
        res.writeHead(200, {"Content-type": "image/png"});
        fs.createReadStream("./favicon.ico").pipe(res);
    }
    else if(url === "/style.css") {
        res.writeHead(200, {"Content-type": "text/css"});
        fs.createReadStream("./style.css").pipe(res);
    }
    else if(url === "/script.js") {
        res.writeHead(200, {"Content-type": "text/javascript"});
        fs.createReadStream("./script.js").pipe(res);
    }
    
});


server.on("listening", () => {
    console.log(`Listening on port ${port}`);
});

server.listen(port);