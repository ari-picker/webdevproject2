const http = require("http");

const port = 3000;
const server = http.createServer();

server.on("listening", () => 
    console.log(`Server running on port ${port}`)
);

server.on("request", (req, res) => {
    res.writeHead(200, {"Content-type":"text/plain"});
	res.write("<h1>Homepage</h1>");
	res.end();
});

server.listen(port);