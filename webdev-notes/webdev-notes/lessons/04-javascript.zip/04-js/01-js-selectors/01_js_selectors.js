let parOne = document.querySelector("p");
console.log(parOne); //prints first html p 

let parArray = document.querySelectorAll("p");
console.log(parArray[1]); //prints second html p

let whiteHouseImg = document.querySelector("img");
whiteHouseImg.src = "https://cdn.britannica.com/08/193808-050-BFDC7569/view-White-House-Washington-DC.jpg";
whiteHouseImg.width = 500;

whiteHouseImg.removeAttribute("alt"); //go to inspect and see img has not alt attribute anymore
