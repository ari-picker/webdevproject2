let submitBtn = document.querySelector("#submit");

submitBtn.addEventListener("click", (event) => {
    window.alert("Submit Button Pressed");
});

