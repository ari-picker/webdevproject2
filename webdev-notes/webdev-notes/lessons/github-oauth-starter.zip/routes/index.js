var express = require('express');
var axios = require("axios");
var crypto = require("crypto")
var router = express.Router();

let stateDirectory = [];

router.get('/', function(req, res) {
  res.render('index');
});

//STEP 1
router.get('/github-auth', async function(req, res) {
  //Create a random state
  //Save the state
  //Fetch Client ID
  //Fetch the Redirect URI

  //Combine all those in a GET to https://github.com/login/oauth/authorize?
  
});

//STEP 2
router.get("/callback", (req, res) => {
  //Get code and state
  //If state corrupt, abort
  //Else exchange code for the access token
});

//STEP 3
async function getToken(req, res, code) {
  //Exchange code for access token with a POST
  //Headers: Accept: application/json
  //Body: client_id, client_secret, code
  //url: https://github.com/login/oauth/access_token
  
  //Get response from axios
  //Send it to the browser as a cookie
  //redirect to /repos path in this server

}

//STEP 4
router.get("/repos", async (req, res) => {
  //get the token from the cookies
  //get all users repos using getAllRepos()
  //get the repos and render the repos page
});

async function getAllRepos(req, res, token) {
  //Use axios GET at https://api.github.com/user/repos
  //headers: Accept: application/vnd.github+json
  //and Authorization": `Bearer ${token}
  //return the repos when done
}



module.exports = router;
