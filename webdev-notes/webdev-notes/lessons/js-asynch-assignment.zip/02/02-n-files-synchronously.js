
const fs = require("fs");
const n = 15;	//input size 0 < n < 100
const content = 'Data-2';
const output_dir = 'output/';

//TODO