
const fs = require("fs");
const { fileURLToPath } = require("url");
const zlib = require("zlib");
const files_dir = "./input/";
const input_files = fs.readdirSync(files_dir);
