
const fs = require("fs");
const content = 'Data-1';
const output_dir = 'output/';
const n = 13;	//input size 0 < n < 100

//TODO