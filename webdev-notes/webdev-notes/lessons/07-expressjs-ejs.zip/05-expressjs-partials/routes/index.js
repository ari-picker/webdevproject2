var express = require('express');
var router = express.Router();

router.get('/', (req, res) => {
    res.render('index');
});

router.get('/browse', (req, res) => {
      const books = [
            { title: "The Quantum Orchard", author: "Lena Moravec", isbn: "978-1-4028-9462-1", edition: 2, price: 39.95 },
            { title: "Midnight Over Avalon", author: "Jared Holloway", isbn: "978-1-86197-876-9", edition: 1, price: 24.50 },
            { title: "The Silent Algorithm", author: "Priya Sen", isbn: "978-0-545-01022-1", edition: 3, price: 44.99 },
            { title: "Neon Tides", author: "Marco Velasquez", isbn: "978-0-7432-7356-5", edition: 1, price: 19.99 },
            { title: "Fragments of Tomorrow", author: "Elise Tanaka", isbn: "978-1-250-30244-7", edition: 2, price: 29.75 },
            { title: "The Atlas Paradox Engine", author: "Connor Blake", isbn: "978-0-316-76948-0", edition: 4, price: 49.95 },
            { title: "Echoes Beneath Orion", author: "Samira Haddad", isbn: "978-0-06-112008-4", edition: 1, price: 27.99 },
            { title: "Crimson Circuits", author: "Derek Wu", isbn: "978-0-399-16405-0", edition: 2, price: 34.25 },
            { title: "The Last Library of Arkon", author: "Tomas Iverson", isbn: "978-1-4767-4658-6", edition: 5, price: 54.00 },
            { title: "Binary Dreams of Solara", author: "Nadia Petrov", isbn: "978-0-141-03435-8", edition: 1, price: 21.95 }
        ];

    res.render('browse', {books: books});
});

router.get('/contact', (req, res) => {
    res.render('contact');
});

module.exports = router;
