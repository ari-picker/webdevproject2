var express = require('express');
var router = express.Router();

/* GET homepage */
router.get('/', function(req, res, next) {
  res.render('index');
});

/* GET login page. */
router.get('/login', function(req, res) {
  res.render('login');
});


router.get('/login-submit', function(req, res, next) {
  console.log(req.query);
  res.render('welcome', {username: req.query.username});
});


module.exports = router;
