const http = require("http");
const fs = require("fs");
const port = 3000;
const server = http.createServer();

server.on("request", handleRequest);

function handleRequest(req, res) {
    console.log(req.method);

    if(req.method === "GET" && req.url === "/"){
        res.writeHead(200, {"Content-Type": "text/html"});
        fs.createReadStream("./index.html").pipe(res);
    } 
    else if(req.url === "/styles.css") {
        res.writeHead(200, {"Content-Type": "text/css"});
        fs.createReadStream("./styles.css").pipe(res);
    }
    else if(req.url === "/mlk-1.jpg") {
        res.writeHead(200, {"Content-Type": "image/jpg"});
        fs.createReadStream("./mlk-1.jpg").pipe(res);
    }
    else if(req.url === "/mlk-2.jpg") {
        res.writeHead(200, {"Content-Type": "image/jpg"});
        fs.createReadStream("./mlk-2.jpg").pipe(res);
    }
    else if(req.url === "/mlk-3.jpg") {
        res.writeHead(200, {"Content-Type": "image/jpg"});
        fs.createReadStream("./mlk-3.jpg").pipe(res);
    }    
}

server.listen(port, () => {
    console.log(`Server listening on port: ${port}`);
});
