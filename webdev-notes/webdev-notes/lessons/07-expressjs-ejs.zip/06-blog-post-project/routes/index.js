var express = require('express');
var router = express.Router();
const posts = [
{
    _id: 1,
    title: "Getting Started with Node.js",
    author: "Alex Rivera",
    content: "Node.js allows developers to run JavaScript outside the browser. It is fast, scalable, and widely used for backend development.",
    date: "March 12, 2026"
},
{
    _id: 2,
    title: "Understanding Express Routing",
    author: "Priya Shah",
    content: "Express makes routing simple and clean. Routes help define how your server responds to client requests.",
    date: "March 14, 2026"
},
{
    _id: 3,
    title: "Intro to EJS Templates",
    author: "Jordan Lee",
    content: "EJS lets developers embed JavaScript directly into HTML, making dynamic pages easy to create.",
    date: "March 16, 2026"
},
{
    _id: 4,
    title: "Why MVC Architecture Matters",
    author: "Sam Carter",
    content: "MVC separates application logic into three components: models, views, and controllers, improving maintainability.",
    date: "March 18, 2026"
},
{
    _id: 5,
    title: "Building Your First Blog App",
    author: "Maria Gomez",
    content: "A blog app is a great beginner project that teaches routing, templating, and CRUD operations.",
    date: "March 20, 2026"
},
{
    _id: 6,
    title: "Working with Forms in Express",
    author: "Chris Patel",
    content: "Handling form submissions in Express requires middleware like express.urlencoded().",
    date: "March 22, 2026"
},
{
    _id: 7,
    title: "Serving Static Files in Express",
    author: "Taylor Nguyen",
    content: "Static assets like CSS and images are served using express.static middleware.",
    date: "March 24, 2026"
},
{
    _id: 8,
    title: "Understanding Middleware",
    author: "Dana White",
    content: "Middleware functions execute during the request-response cycle and help modify requests or responses.",
    date: "March 26, 2026"
},
{
    _id: 9,
    title: "Sessions vs JWT Authentication",
    author: "Ethan Brooks",
    content: "Sessions store user data server-side, while JWT stores authentication data client-side.",
    date: "March 28, 2026"
},
{
    _id: 10,
    title: "Deploying Your Express App",
    author: "Lina Hassan",
    content: "Deployment platforms like Render and Railway make publishing Node apps simple and fast.",
    date: "March 30, 2026"
}
];
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

/* GET signup page. */
router.get('/signup', function(req, res, next) {
  res.render('signup');
});

/* POST signup page. */
router.post('/singup', function(req, res, next) {
  // TODO: Handle the sigup information
});

/* GET login page. */
router.get('/login', function(req, res, next) {
  res.render('login');
});

/* POST login page. */
router.post('/login', function(req, res, next) {
  // TODO: Handle the login information
  // TODO: Redirect the user to the /feed page if authentication is correct
  res.redirect("/feed");
});

/* GET feed page. */
router.get('/feed', function(req, res, next) {
  res.render('feed', {posts});
});

/* GET profile page. */
router.get('/profile', function(req, res, next) {
  res.render('profile');
});

/* GET compose page. */
router.get('/compose', function(req, res, next) {
  res.render('compose');
});

module.exports = router;
